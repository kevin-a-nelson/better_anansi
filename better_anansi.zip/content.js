var main = document.getElementById("main")
var editArea = document.getElementById("edit_area")

main.appendChild(editArea)

document.getElementById("prompt_outer").style.flex = "none"
document.getElementById("prompt_outer").style.width = "33vw"

document.getElementById("workspace").style.flex = "none"
document.getElementById("workspace").style.width = "33vw"

document.getElementById("edit_area").style.flex = "none"
document.getElementById("edit_area").style.width = "33vw"